import javax.swing.*;
import java.awt.*;
import java.awt.event.*; // Make buttons have functions
import java.util.ArrayList;

//TODO: For when we implement our other pages...
//TODO: Implement page navigation options (Back a page, Forward a page, Home button, etc.)

//TODO: Additional suggestions:
//TODO: Implement doctor sorting methods(?)

public class GUI {
    JFrame jfrm = new JFrame();
    ArrayList<Doctor> doctorList = new ArrayList<>();
    ArrayList<InnerDoctor> doctorAssets = new ArrayList<>();
    ArrayList<JPanel> doctorListVisual = new ArrayList<>();

    GUI(String title, ArrayList<Doctor> dL) { //Main method of class used to display the user interface
        doctorList.addAll(dL);

        jfrm.setTitle(title);
        jfrm.setSize(800, 500); //default dimensions W: 800, H: 500
        jfrm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jfrm.setLayout(new BoxLayout(jfrm.getContentPane(), BoxLayout.Y_AXIS));

        for (Doctor doctor : doctorList) {   //Manifest a list of associated assets with each doctor
            doctorAssets.add(new InnerDoctor(doctor));
        }
        for (InnerDoctor doctorAsset : doctorAssets) { //Organize grouped assets into a panel
            doctorListVisual.add(makePanel(doctorAsset));
        }

        JPanel mainPane = new JPanel();
        mainPane.setLayout(new BoxLayout(mainPane, BoxLayout.Y_AXIS));

        for (JPanel jPanel : doctorListVisual) {
            mainPane.add(jPanel);
        }

        JScrollPane jsp = new JScrollPane(mainPane, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        jfrm.add(jsp);

        jfrm.setVisible(true);
    }

    private JPanel makePanel(InnerDoctor innerDoctor) { //Creates a panel holding all the related information of each respective doctor for display in search
        JPanel panel = new JPanel();
        panel.setSize(750, 200);
        panel.setLayout(new BorderLayout());

        JPanel miniPanel1 = new JPanel(); //Holds doctor profile picture
        JPanel miniPanel2 = new JPanel(); //Holds doctor info
        JPanel miniPanel3 = new JPanel(); //Holds schedule appointment button

        miniPanel1.setLayout(new FlowLayout());
        miniPanel2.setLayout(new BoxLayout(miniPanel2, BoxLayout.Y_AXIS));
        miniPanel3.setLayout(new BorderLayout());

        miniPanel1.setSize(150, 150); //Not really important, but for integrity's sake
        miniPanel2.setSize(150, 150);
        miniPanel3.setSize(150, 75);

        miniPanel1.add(innerDoctor.docPfp128bit);
        miniPanel2.add(innerDoctor.docName);
        miniPanel2.add(innerDoctor.docSpecialty);
        miniPanel2.add(innerDoctor.docPhone);
        miniPanel2.add(innerDoctor.docEmail);

        JButton scheduleButton = new JButton("Schedule Appointment");
//        scheduleButton.setBackground(new Color(255, 69, 125)); //Custom color for schedule button, but it removes the gradient effect
        miniPanel3.add(scheduleButton, BorderLayout.EAST);

        panel.add(miniPanel1, BorderLayout.WEST);
        panel.add(miniPanel2, BorderLayout.CENTER);
        panel.add(miniPanel3, BorderLayout.EAST);

        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        return panel;
    }

    private static class InnerDoctor { //Inner class used to describe objects that hold the visual information on a doctor
        JLabel docName = new JLabel();
        JLabel docEmail = new JLabel();
        JLabel docPhone = new JLabel();
        JLabel docSpecialty = new JLabel();
        JLabel docID = new JLabel();
        JLabel docPfp64bit = new JLabel();
        JLabel docPfp128bit = new JLabel();

        InnerDoctor(Doctor doctor) {
            docName.setText("Dr. " + doctor.getName());
            docPhone.setText(doctor.getPhoneNumber());
            docEmail.setText(doctor.getEmail());
            docSpecialty.setText(doctor.getSpecialty());
            docID.setText(doctor.getDoctorID());

            docName.setFont(new Font("DocBold", Font.BOLD, 18));
            docPhone.setFont(new Font("DocPhone", Font.PLAIN, 14));
            docEmail.setFont(new Font("DocEmail", Font.PLAIN, 14));
            docSpecialty.setFont(new Font("DocSpecialty", Font.PLAIN, 14));
            docID.setFont(new Font("DocID", Font.PLAIN, 14));

            Image scaledIcon64 = doctor.getPfp().getScaledInstance(64 ,64, Image.SCALE_DEFAULT);
            ImageIcon docIcon64 = new ImageIcon(scaledIcon64);
            docPfp64bit.setIcon(docIcon64);
            docPfp64bit.setBorder(BorderFactory.createLineBorder(Color.BLACK));

            Image scaledIcon128 = doctor.getPfp().getScaledInstance(128, 128, Image.SCALE_DEFAULT);
            ImageIcon docIcon128 = new ImageIcon(scaledIcon128);
            docPfp128bit.setIcon(docIcon128);
            docPfp128bit.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        }
    }
}