import java.io.File;
import java.awt.*;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.util.ArrayList;

public class Main {
    public static ArrayList<Doctor> doctorList = new ArrayList<>();

    public static void main(String[] args) throws IOException {
        initializeDoctors();
        GUI findDoctorFrame = new GUI("Find a Doctor", doctorList);
    }

    public static void initializeDoctors() throws IOException {
        Doctor house = new Doctor("Gregory House", "greghouse@wch.com", "(909) 387-3472", "Infectious Diseases", "0001");
        Doctor murphy = new Doctor("Shaun Murphy", "shaunmurphy@wch.com", "(909) 943-1189", "Open Surgery", "0002");
        Doctor zoidberg = new Doctor("John Zoidberg", "johnzoid@wch.com", "(951) 821-3560", "Internal Medicine", "0003");
        Doctor strange = new Doctor("Stephen Strange", "stephstrange@wch.com", "(760) 982-9293", "Neurosurgery", "0004");
        Doctor doofenshmirtz = new Doctor("Heinz Doofenshmirtz", "heinzdoof@wch.com", "(323) 163-7235", "Pharmacist", "0005");
        Doctor banner = new Doctor("Bruce Banner", "bruceban@wch.com", "(310) 352-8462", "Radiation Oncology", "0006");
        Doctor who11 = new Doctor("Who (11)", "who11@wch.com", "(909) 387-3411", "Neurology", "0011");
        Doctor who12 = new Doctor("Who (12)", "who12@wch.com", "(909) 387-3412", "Psychiatry", "0012");

        house.setPfp(ImageIO.read(new File("Doctor Pictures/house.jpg")));
        murphy.setPfp(ImageIO.read(new File("Doctor Pictures/murphy.png")));
        zoidberg.setPfp(ImageIO.read(new File("Doctor Pictures/zoidberg.png")));
        strange.setPfp(ImageIO.read(new File("Doctor Pictures/strange.jpg")));
        doofenshmirtz.setPfp(ImageIO.read(new File("Doctor Pictures/doofenshmirtz.png")));
        banner.setPfp(ImageIO.read(new File("Doctor Pictures/banner.png")));
        who11.setPfp(ImageIO.read(new File("Doctor Pictures/doctor11.jpg")));
        who12.setPfp(ImageIO.read(new File("Doctor Pictures/doctor12.png")));

        doctorList.add(house);
        doctorList.add(murphy);
        doctorList.add(zoidberg);
        doctorList.add(strange);
        doctorList.add(doofenshmirtz);
        doctorList.add(banner);
        doctorList.add(who11);
        doctorList.add(who12);
    }
}