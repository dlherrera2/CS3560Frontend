import java.awt.*;

public class Doctor extends Person {
    String specialty;
    String DoctorID;
    Image pfp;

    Doctor(String name, String email, String phoneNumber, String specialty, String DoctorID) { //All fields; All arguments
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.specialty = specialty;
        this.DoctorID = DoctorID;
    }

    Doctor() { //Default; No arguments
        name = "John Doe";
        email = "johndoe@wch.com";
        phoneNumber = "(123) 456-7890";
        specialty = "N/A";
        DoctorID = "0000";
    }

    public void setName(String name) {
        this.name = name;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }
    public void setDoctorID(String DoctorID) {
        this.DoctorID = DoctorID;
    }
    public void setPfp(Image pfp) {
        this.pfp = pfp;
    }

    public String getName() {
        return name;
    }
    public String getEmail() {
        return email;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }
    public String getSpecialty() {
        return specialty;
    }
    public String getDoctorID() {
        return DoctorID;
    }
    public Image getPfp() {
        return pfp;
    }
}